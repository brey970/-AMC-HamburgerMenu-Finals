import React, { useState } from 'react';
import {
  SafeAreaView,
  Animated,
  View,
  TouchableOpacity,
  Text,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { Menu, X } from 'lucide-react-native';

const HamburgerMenu = ({ navigation }) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const slideAnim = useState(new Animated.Value(-300))[0];

  const toggleMenu = () => {
    const toValue = menuOpen ? -300 : 0;

    Animated.timing(slideAnim, {
      toValue,
      duration: 300,
      useNativeDriver: true,
    }).start();

    setMenuOpen(!menuOpen);
  };

  const navigateToScreen = (screenName) => {
    setMenuOpen(false); // Close the menu after navigation
    if (navigation && navigation.navigate) {
      navigation.navigate(screenName);
    } else {
      console.warn(`Navigation prop not passed or 'navigate' function not available.`);
      // You might want to handle this case differently in your app
    }
  };

  const menuItems = [
    { id: 1, title: 'Home', screen: 'HomeScreen' },
    { id: 2, title: 'Profile', screen: 'ProfileScreen' },
    // Add more menu items as needed
  ];

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={toggleMenu} style={styles.menuButton}>
          {menuOpen ? <X size={24} color="#333" /> : <Menu size={24} color="#333" />}
        </TouchableOpacity>
        <Text style={styles.headerTitle}>My App</Text>
      </View>

      {menuOpen && (
        <TouchableOpacity
          style={styles.overlay}
          activeOpacity={1}
          onPress={toggleMenu}
        />
      )}

      <Animated.View
        style={[
          styles.menu,
          { transform: [{ translateX: slideAnim }] },
        ]}
      >
        <ScrollView>
          <View style={styles.menuHeader}>
            <Text style={styles.menuHeaderText}>Menu</Text>
          </View>

          <View>
            {menuItems.map((item) => (
              <TouchableOpacity
                key={item.id}
                style={styles.menuItem}
                onPress={() => navigateToScreen(item.screen)}
              >
                <Text style={styles.menuItemText}>{item.title}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f4f8', // Light grey background
  },
  header: {
    height: 60,
    backgroundColor: '#ffe4e1', 
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0', 
    elevation: 1, 
  },
  menuButton: {
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '600', 
    marginLeft: 15,
    color: '#63666A1', 
  },
  overlay: {
    position: 'absolute',
    top: 60,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.3)', 
    zIndex: 1,
  },
  menu: {
    position: 'absolute',
    top: 60,
    left: 0,
    width: 280, 
    backgroundColor: '#fff',
    zIndex: 2,
    shadowColor: '#000',
    shadowOffset: { width: 5, height: 0 }, 
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 8,
  },
  menuHeader: {
    paddingVertical: 20,
    paddingHorizontal: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  menuHeaderText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#555',
  },
  menuItem: {
    paddingVertical: 15,
    paddingHorizontal: 15,
  },
  menuItemText: {
    fontSize: 16,
    color: '#333',
  },
});

export default HamburgerMenu;